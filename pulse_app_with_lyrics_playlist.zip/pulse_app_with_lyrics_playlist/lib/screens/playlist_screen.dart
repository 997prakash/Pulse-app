
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PlaylistScreen extends StatelessWidget {
  const PlaylistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: const Text('Your Playlist')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('songs').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final songs = snapshot.data!.docs;
          return ListView.builder(
            itemCount: songs.length,
            itemBuilder: (context, index) {
              var song = songs[index];
              return ListTile(
                title: Text(song['title'], style: const TextStyle(color: Colors.white)),
                subtitle: Text(song['artist'], style: const TextStyle(color: Colors.grey)),
                onTap: () {
                  // placeholder for future player/lyrics
                },
              );
            },
          );
        },
      ),
    );
  }
}
