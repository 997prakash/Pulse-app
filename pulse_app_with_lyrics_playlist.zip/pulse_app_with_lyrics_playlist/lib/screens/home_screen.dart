
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'playlist_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Pulse'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: Center(
        child: ElevatedButton(
          child: const Text('Go to Playlist'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const PlaylistScreen()));
          },
        ),
      ),
    );
  }
}
